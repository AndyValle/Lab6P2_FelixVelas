/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import lab.usuarios.Usuario;

/**
 *
 * @author Usuario
 */
public class Loader {
    
    public static String folder = "./data/";
    
    public boolean guardarTodos(List<Usuario> usuarios, String subfolder) {
        if (!usuarios.stream().noneMatch(usuario -> (!guardarUno(usuario, subfolder)))) {
            return false;
        }
        return true;
    }

    public boolean guardarUno(Usuario usuario, String subfolder) {
        try {
            FileOutputStream fos = new FileOutputStream(folder + subfolder + usuario.toString().concat(".txt"));
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(usuario);
            oos.close();
            fos.close();
        } catch (IOException ex) {
            return false;
        }
        return true;
    }

    public <T> List<T> leerVarios(String[] archivos, String root) {
        List<T> list = new ArrayList();

        for(int i = 0; i < archivos.length; i++){
            list.add((T) leerUno(folder + root + archivos[i]));
        };

        return list;
    }

    public Object leerUno(String archivo) {
        FileInputStream fileIn;
        Object ob = null;

        try {
            fileIn = new FileInputStream(archivo);
            ObjectInputStream in = new ObjectInputStream(fileIn);
            ob = in.readObject();
            in.close();
            fileIn.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Loader.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Loader.class.getName()).log(Level.SEVERE, null, ex);
        }

        return ob;
    }
}
