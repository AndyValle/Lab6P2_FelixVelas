/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.usuarios;

/**
 *
 * @author Usuario
 */
public class Estudiante extends Usuario {
    
    private String carrera;
    private Integer año_cursando;
    private Integer años_carrera;

    public Estudiante(String nombre, String apellido, String correo_e, String carrera,
            Integer año_cursando, Integer años_carrera) {
        super(nombre, apellido, correo_e);
        this.carrera = carrera;
        this.año_cursando = año_cursando;
        this.años_carrera = años_carrera;
        path = "estudiantes/";
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public Integer getAño_cursando() {
        return año_cursando;
    }

    public void setAño_cursando(Integer año_cursando) {
        this.año_cursando = año_cursando;
    }

    public Integer getAños_carrera() {
        return años_carrera;
    }

    public void setAños_carrera(Integer años_carrera) {
        this.años_carrera = años_carrera;
    }
}
