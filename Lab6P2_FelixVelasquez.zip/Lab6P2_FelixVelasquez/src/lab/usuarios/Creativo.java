/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.usuarios;

/**
 *
 * @author Usuario
 */
public class Creativo extends Usuario {
    
    private String ocupacion;
    private Integer edad;

    public Creativo(String nombre, String apellido, String correo_e, String ocupacion, Integer edad) {
        super(nombre, apellido, correo_e);
        this.ocupacion = ocupacion;
        this.edad = edad;
        path = "creativos/";
    }

    public String getOcupacion() {
        return ocupacion;
    }

    public void setOcupacion(String ocupacion) {
        this.ocupacion = ocupacion;
    }

    public Integer getEdad() {
        return edad;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }

}
