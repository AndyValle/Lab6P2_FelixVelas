/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.usuarios;

/**
 *
 * @author Usuario
 */
public class Normal extends Usuario {

    
    
    public enum Interes {
        Indefinido, Cocina, Musica, Libros, Hogar
    };
    
    private String hobby;
    private Interes intereses;

    public Normal(String nombre, String apellido, String correo_e, String hobby) {
        super(nombre, apellido, correo_e);
        this.hobby = hobby;
        path = "normales/";
    }

    public Normal(String nombre, String apellido, String correo_e, String hobby,
            Interes intereses) {
        super(nombre, apellido, correo_e);
        this.hobby = hobby;
        path = "normales/";
    }

    public String getHobby() {
        return hobby;
    }

    public void setHobby(String hobby) {
        this.hobby = hobby;
    }

    public Interes getIntereses() {
        return intereses;
    }

    public void setIntereses(Interes intereses) {
        this.intereses = intereses;
    }

}
