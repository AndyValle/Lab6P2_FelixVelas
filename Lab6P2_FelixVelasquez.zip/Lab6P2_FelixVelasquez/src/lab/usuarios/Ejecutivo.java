/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.usuarios;

/**
 *
 * @author Usuario
 */
public class Ejecutivo extends Usuario {
    
    private String cargo;
    private String empresa;
    private String titulo;
    private String titulo_maestria;

    public Ejecutivo(String nombre, String apellido, String correo_e, String cargo,
            String empresa, String titulo, String titulo_maestria) {
        super(nombre, apellido, correo_e);
        this.cargo = cargo;
        this.empresa = empresa;
        this.titulo = titulo;
        this.titulo_maestria = titulo_maestria;
        path = "ejecutivos/";
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTitulo_maestria() {
        return titulo_maestria;
    }

    public void setTitulo_maestria(String titulo_maestria) {
        this.titulo_maestria = titulo_maestria;
    }

}
