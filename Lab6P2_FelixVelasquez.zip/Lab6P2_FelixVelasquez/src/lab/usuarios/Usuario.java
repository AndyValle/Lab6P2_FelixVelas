/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.usuarios;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

import lab.notas.Nota;

/**
 *
 * @author Usuario
 */
public abstract class Usuario implements Serializable {

    protected String path = "";
    
    // Login
    protected String usuario;
    protected String contraseña;

    // Informacion basica
    protected String nombre;
    protected String apellido;
    protected String correo_e;
    
    protected List<Nota> notas;

    public Usuario(String nombre, String apellido, String correo_e) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo_e = correo_e;
        this.notas = new ArrayList();
    }
    
    public void agregarNota(Nota nota){
        notas.add(nota);
    }
    
    public void eliminarNota(int index){
        notas.remove(index);
    }
    
    public Nota getNota(int index){
        return notas.get(index);
    }
    
    public Nota setNota(int index, Nota nota){
        return notas.set(index, nota);
    }
    
    public List<Nota> getNotas(){
        return this.notas;
    }
    
    public void setNotas(List<Nota> notas){
        this.notas = notas;
    }

    public boolean Login(String usuario, String contraseña) {
        return this.usuario.equals(usuario) && this.contraseña.equals(contraseña);
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreo_e() {
        return correo_e;
    }

    public void setCorreo_e(String correo_e) {
        this.correo_e = correo_e;
    }
    
    public String getPath(){
        return path;
    }

    @Override
    public String toString() {
        return this.usuario;
    }
}
