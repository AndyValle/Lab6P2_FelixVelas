/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import lab.usuarios.*;

/**
 *
 * @author Usuario
 */
public class Administrador {

    Loader loader;
    File normales;
    File ejecutivos;
    File estudiantes;
    File creativos;

    List<Normal> l_normales;
    List<Creativo> l_creativos;
    List<Ejecutivo> l_ejecutivos;
    List<Estudiante> l_estudiantes;

    public Administrador() {
        loader = new Loader();
        normales = new File(Loader.folder + "normales/");
        ejecutivos = new File(Loader.folder + "ejecutivos/");
        estudiantes = new File(Loader.folder + "estudiantes/");
        creativos = new File(Loader.folder + "creativos/");
    }

    public List<Usuario> getTodosUsuarios() {

        List<Usuario> usuarios = new ArrayList();
        usuarios.addAll(loader.<Usuario>leerVarios(normales.list(), "normales/"));
        usuarios.addAll(loader.<Usuario>leerVarios(ejecutivos.list(), "ejecutivos/"));
        usuarios.addAll(loader.<Usuario>leerVarios(estudiantes.list(), "estudiantes/"));
        usuarios.addAll(loader.<Usuario>leerVarios(creativos.list(), "creativos/"));

        return usuarios;
    }
    
    public boolean guardar(Usuario usuario){
        return loader.guardarUno(usuario, usuario.getPath());
    }
}
