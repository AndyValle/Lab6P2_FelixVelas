/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.notas;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class Nota implements Serializable {

    public Date getFecha_recordatorio() {
        return fecha_recordatorio;
    }

    public void setFecha_recordatorio(Date fecha_recordatorio) {
        this.fecha_recordatorio = fecha_recordatorio;
    }

    public enum Categoria {
        Audiovisuales, Literatura, Arte
    };

    public enum Prioridad {
        Baja, Media, Alta
    };

    private Categoria categoria;
    private Prioridad prioridad;
    private String titulo;
    private String titulo_recordatorio;
    private String titulo_reunion;
    private String texto;
    private String asunto;
    private String descripcion;
    private List<String> invitados;
    private List<String> etiquetas;

    private Date fecha_recordatorio;
    private LocalDateTime fecha_creacion;

    public String getTitulo_recordatorio() {
        return titulo_recordatorio;
    }

    public void setTitulo_recordatorio(String titulo_recordatorio) {
        this.titulo_recordatorio = titulo_recordatorio;
    }

    public Prioridad getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(Prioridad prioridad) {
        this.prioridad = prioridad;
    }

    public void setPrioridad(String prioridad) {
        this.prioridad = Nota.Prioridad.valueOf(prioridad);
    }

    public String getTitulo_reunion() {
        return titulo_reunion;
    }

    public void setTitulo_reunion(String titulo_reunion) {
        this.titulo_reunion = titulo_reunion;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }
    
    public void setCategoria(String categoria) {
        this.categoria = Nota.Categoria.valueOf(categoria);
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public List<String> getInvitados() {
        return invitados;
    }

    public void setInvitados(List<String> invitados) {
        this.invitados = invitados;
    }

    public List<String> getEtiquetas() {
        return etiquetas;
    }

    public void setEtiquetas(List<String> etiquetas) {
        this.etiquetas = etiquetas;
    }

    public LocalDateTime getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(LocalDateTime fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }

    @Override
    public String toString() {
        return this.getTitulo();
    }
}
